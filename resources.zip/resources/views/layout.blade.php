<!DOCTYPE html>
<html>
<head>
    <title>Dental Clinic System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/tailwind.min.css">
</head>
<body class="p-6">
    <div class="container mx-auto">
        @yield('content')
    </div>
</body>
</html>
