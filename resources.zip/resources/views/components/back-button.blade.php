@props([
    'fallback' => null,                 // required fallback URL/route string
    'class' => 'btn-ghostx',
    'label' => 'Back',
])

@php
    $returnUrl = request('return') ?? old('return');

    $isSafe = function (?string $url) {
        if (!$url) return false;
        $host = parse_url($url, PHP_URL_HOST);
        return !$host || $host === request()->getHost();
    };

    $backUrl = null;

    // 1) explicit ?return=...
    if ($isSafe($returnUrl)) {
        $backUrl = $returnUrl;
    }

    // 2) real previous page
    if (!$backUrl) {
        $prev = url()->previous();
        if ($isSafe($prev) && $prev !== url()->current()) {
            $backUrl = $prev;
        }
    }

    // 3) fallback
    if (!$backUrl) {
        $backUrl = $fallback ?: url('/');
    }
@endphp

<a href="{{ $backUrl }}" class="{{ $class }}">
    <i class="fa fa-arrow-left"></i> {{ $label }}
</a>
